import React from 'react'
import Template from '../components/Template'

export default function Tutorials() {
  return (
    <>
    <Template sectionName="Tutorials" buttonTitle = "Post a tutorial"/>
    </>
  )
}
