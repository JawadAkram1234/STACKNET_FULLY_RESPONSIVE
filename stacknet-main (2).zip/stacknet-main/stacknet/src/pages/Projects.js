import React from 'react'
import Template from '../components/Template'
// import LoginPopup from '../components/LoginPopup'
// import SignupPopup from '../components/SignupPopup'

export default function Projects() {
  return (
    <Template sectionName="Projects Showcase" buttonTitle = "Add project" />
  )
}
