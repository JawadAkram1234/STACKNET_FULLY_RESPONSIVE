import { createContext } from "react";

const IsLoggedInContext = createContext();

export default IsLoggedInContext;