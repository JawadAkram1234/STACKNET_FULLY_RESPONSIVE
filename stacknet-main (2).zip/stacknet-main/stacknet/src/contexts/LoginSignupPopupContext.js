import { createContext } from "react";

const LoginSignupPopupContext = createContext();

export default LoginSignupPopupContext;